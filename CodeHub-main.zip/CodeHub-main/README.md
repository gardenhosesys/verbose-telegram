# CodeHub

### A website that uses Front End Technologies, and Frame Works, which is based on a iOS Mock-Up

# Technologies
- HTML5
- CSS3
- BootStrap
# Usage 
Clone and install dependencies.
```
git clone https://github.com/Mesmerize/CodeHub.git
cd CodeHub
npm install
````
Run the app
```
Open with default application or live server
``````
# Preview

https://drive.google.com/file/d/1bOEnN3IxWczNmyGKEvQqb9y_kO16IVKN/view?usp=sharing
